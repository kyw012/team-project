# 🏋️‍♂️ AI Motion Fitness System (AI 智慧健身系統)

這是一個整合 Google MediaPipe (動作偵測)、Gemini AI (智慧教練) 與 Firebase (雲端資料庫) 的全端健身應用程式。使用者可以透過攝影機進行深蹲訓練，系統會即時計算次數、分析動作，並將數據視覺化呈現。

## 🌟 系統特色

- **即時動作偵測**：使用電腦視覺技術，無需穿戴裝置即可偵測深蹲動作。

- **雲端數據同步**：所有訓練紀錄、個人資料皆儲存於 Firebase Firestore，跨裝置不遺失。

- **視覺化儀表板**：
  - 每週摘要：卡路里、總次數、平均分數。
  - 體能趨勢圖 (折線圖)：追蹤每日體能評分變化。
  - 每週運動量 (長條圖)：統計一週內每日的運動強度。

- **AI 智能分析**：一鍵生成訓練建議，或與 AI 教練對話。

- **完整會員系統**：支援註冊、登入、補全資料與修改密碼。

## 🛠️ 前置準備 (必要金鑰申請)

本系統依賴兩個雲端服務，請先申請 API Key：

### 1. Google Gemini API (AI 功能)

- 前往 Google AI Studio。
- 登入 Google 帳號。
- 點擊左上角 "Get API key" -> "Create API key"。
- 複製 AIza 開頭的字串。

### 2. Firebase 專案 (資料庫與登入)

- 前往 Firebase Console 並建立新專案。

**新增 Web App**：
- 在專案總覽頁面點擊 </> (Web) 圖示。
- 註冊應用程式，複製 `const firebaseConfig = { ... }` 整段物件內容。

**啟用 Authentication (身份驗證)**：
- 左側選單點選 Build > Authentication。
- 點擊 Sign-in method 分頁。
- 啟用 Email/Password (電子郵件/密碼)，並確認將第一個開關設為 Enable。

**建立 Firestore Database**：
- 左側選單點選 Build > Firestore Database。
- 點擊 Create database。
- 選擇 Start in test mode (測試模式) 以允許讀寫權限 (或稍後在 Rules 設定 `allow read, write: if true;`)。

## ⚙️ 程式碼設定

1. 使用文字編輯器 (如 VS Code, Notepad++) 開啟 `AI_Fitness_System_Stable.html`。

2. 找到檔案上方約 **第 85 行** 的設定區塊：

```javascript
// =================================================================================
//  使用者設定區塊 (請務必填寫)
// =================================================================================

const firebaseConfig = {
    apiKey: "貼上您的_FIREBASE_API_KEY",
    authDomain: "您的專案ID.firebaseapp.com",
    projectId: "您的專案ID",
    // ... 其他欄位請一併填入
};

const geminiApiKey = "貼上您的_AIza_GEMINI_KEY";
```

3. 將您申請的真實金鑰填入引號中並存檔。

## 🚀 啟動方式 (重要！)

⚠️ 由於瀏覽器安全性限制，請勿直接雙擊檔案開啟 (網址列顯示 file://...)，這會導致相機無法啟動且程式報錯。

請務必透過「本機伺服器 (Localhost)」執行：

### 方法 A：使用 VS Code (推薦)

1. 安裝擴充套件 Live Server。
2. 在 HTML 檔案編輯區按右鍵，選擇 "Open with Live Server"。
3. 瀏覽器將自動開啟 (網址如 `http://127.0.0.1:5500/...`)。

### 方法 B：使用 Python

1. 開啟終端機 (Terminal/CMD)，進入檔案所在資料夾。
2. 輸入指令：`python -m http.server 8000`
3. 開啟瀏覽器輸入：`http://localhost:8000/AI_Fitness_System_Stable.html`

## 📖 操作指南

### 1. 註冊與登入

- **首次使用**：點擊「註冊」分頁，輸入暱稱、Email 與密碼 (需 6 位數以上)。
- **登入**：輸入 Email 與密碼。
- **補全資料**：若系統發現您已登入但沒有暱稱 (例如舊帳號)，會自動跳出提示請您補填。

### 2. 儀表板 (Dashboard)

- 登入後首頁即為儀表板。
- 上方卡片顯示本週的總次數、消耗卡路里等摘要。
- 下方圖表：
  - **體能趨勢**：折線圖顯示您的動作評分變化。
  - **每週運動量**：長條圖顯示本週每日的訓練次數。

### 3. 開始訓練 (Workout)

- 點擊上方導覽列的「訓練」或儀表板的「進入訓練模式」。
- 點擊畫面中央的 **「啟動相機」** 按鈕，並允許瀏覽器權限。

**動作說明**：
- 請退後直到全身入鏡 (系統偵測到頭、膝、踝)。
- 做 **深蹲 (Squat)** 動作：站立 → 下蹲 → 站立。
- 系統會自動計數並給予評分 (AiScore)。
- 訓練結束後，務必點擊右下角的 **「結束並儲存」**，資料才會寫入資料庫。

### 4. 數據報告 (Report)

- 查看詳細的歷史訓練列表。
- 點擊右上角的 **「AI 分析」** 按鈕，Gemini 會根據您最近 5 筆數據提供建議。

### 5. 帳號管理 (Profile)

- 可修改顯示暱稱。
- **修改密碼**：輸入新密碼並儲存 (注意：Firebase 要求修改密碼需為「最近登入」狀態，若失敗請登出再登入一次即可)。

## ❓ 常見問題排除 (Troubleshooting)

| 問題狀況 | 可能原因與解法 |
|---------|--------------|
| 相機無法啟動 / 黑屏 | 1. 檢查網址是否為 `http://localhost` (不可用 `file://`)。<br>2. 檢查瀏覽器網址列是否封鎖了相機權限。<br>3. 確認電腦沒有其他程式占用相機。 |
| 登入失敗：auth/operation-not-allowed | 請至 Firebase Console > Authentication，確認 Email/Password 選項已開啟 (Enable)。 |
| 資料無法儲存 / 權限不足 | 請至 Firebase Console > Firestore Database > Rules，確認規則已設定為 `allow read, write: if true;`。 |
| 圖表沒顯示數據 | 請先完成一次訓練並按下「結束並儲存」。若仍無數據，請確認 Firebase Config 中的 projectId 是否正確。 |
| 修改密碼失敗 | 為了安全，修改密碼需要新鮮的登入憑證。請點擊「登出」，重新登入後立即去修改。 |

---

Created for AI Motion Fitness Project
